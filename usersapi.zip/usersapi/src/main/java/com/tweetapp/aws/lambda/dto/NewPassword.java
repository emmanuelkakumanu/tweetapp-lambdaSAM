package com.tweetapp.aws.lambda.dto;

public class NewPassword {
	public String newPassword;

	public NewPassword() {
		super();
	}

	public NewPassword(String newPassword) {
		super();
		this.newPassword = newPassword;
	}
	
}
